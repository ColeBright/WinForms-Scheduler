﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ColeBrightSchedulingAppC969
{
    public partial class Schedule : Form
    {
        private string ultimatestring;
        public Schedule()
        {
            InitializeComponent();
            tb1.Multiline = true;
            tb1.ScrollBars = ScrollBars.Vertical;

        }

        private void Schedule_Load(object sender, EventArgs e)
        {
            
            MySqlConnection con = new MySqlConnection("server=52.206.157.109;userid=U062m2;database=U062m2;password=53688674498;port=3306;SslMode=None;convert zero datetime=True");
            try
            {
                con.Open();
                String sqlString1 = "SELECT * FROM customer;";
                MySqlCommand cmd1 = new MySqlCommand(sqlString1, con);
                MySqlDataAdapter adp1 = new MySqlDataAdapter(cmd1);
                DataTable ds1 = new DataTable();
                adp1.Fill(ds1);
                string sqlString2 = "SELECT * FROM appointment;";
                MySqlCommand cmd2 = new MySqlCommand(sqlString2, con);
                MySqlDataAdapter adp2 = new MySqlDataAdapter(cmd2);
                DataTable ds2 = new DataTable();
                adp2.Fill(ds2);
                foreach (DataRow Customer in ds1.Rows)
                {
                   CurrentID.CurrentUserId = Int32.Parse((Customer["customerId"]).ToString());
                   ultimatestring = ultimatestring + Customer["customerName"].ToString();
                   ultimatestring = ultimatestring + "---";
                     foreach (DataRow Appointment in ds2.Rows)
                     {
                        if (Int32.Parse((Appointment["customerId"]).ToString()) == CurrentID.CurrentUserId)
                        {
                            ultimatestring = ultimatestring + (Appointment["start"].ToString())
                              + "   -   " + (Appointment["end"].ToString()) +
                              "\r\n" + "\r\n";
                        }
                     }
                    ultimatestring = ultimatestring + "\r\n\r\n";
                    }                
                tb1.Text = ultimatestring;
                }
            finally
            {
                con.Close();
            }
        }

        private void tb1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
