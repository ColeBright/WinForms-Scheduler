﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ColeBrightSchedulingAppC969
{
    static class CurrentID
    {
        public static int SelectedID { get; set; }
        public static int ApptID { get; set; }
        public static string CurrentUser { get; set; }
        public static int CurrentUserId { get; set; }
        public static DateTime SelectedDate { get; set; }
    }
}
