﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ColeBrightSchedulingAppC969
{
    public partial class UserLog : Form
    {
        public UserLog()
        {
            InitializeComponent();
            textBox1.Multiline = true;
            textBox1.ScrollBars = ScrollBars.Vertical;
            string docPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            using (StreamReader outputFile = new StreamReader(Path.Combine(docPath, "LoginLogs.txt"), true))
            {
                textBox1.Text = outputFile.ReadToEnd();
            }
        }


    }
}
